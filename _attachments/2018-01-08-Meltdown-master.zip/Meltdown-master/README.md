# Meltdown
Meltdown PoC for reading passwords from Google Chrome.

FOR EDUCATIONAL AND INFORMATIONAL PURPOSES ONLY.

I am not responsible for any loss or damages from the use of this in any way.
