alert("if you can read this, the script has been injected. This will be the minner");
