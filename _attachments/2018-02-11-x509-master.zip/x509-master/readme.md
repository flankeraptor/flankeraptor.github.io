MalCert proof of concept to accompany blog post

This is a POC demonstrating a covert channel over x509 extensions framework written in GO, for the server and pcap this demonstration shows sending mimikatz over this covert channel to a client. The filename was hardcoded "mimikatz.bin". The PCAP is from a run using local loopback. 


Blog: https://www.fidelissecurity.com/threatgeek/2018/02/exposing-x509-vulnerabilities
Paper: vixra.org/abs/1801.0016
